__version__ = '1.2.0'
__description__ = 'Limits bandwidth of devices on the same network'